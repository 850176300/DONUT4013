﻿using UnityEngine;
using System.Collections;

[ExecuteInEditMode]
public class ParticleSortingLayer : MonoBehaviour
{

    public int orderInLayer = 0;

    void Start()
    {
        // Set the sorting layer of the particle system.
        //particleSystem.renderer.sortingLayerName = "foreground";
        GetComponent<ParticleSystem>().GetComponent<Renderer>().sortingOrder = orderInLayer;
    }

#if UNITY_EDITOR
    void Update()
    {
        if (GetComponent<ParticleSystem>().GetComponent<Renderer>().sortingOrder!=orderInLayer)
            GetComponent<ParticleSystem>().GetComponent<Renderer>().sortingOrder = orderInLayer;
    }
#endif
}