package com.common.android.jni;

import java.util.HashMap;
import java.util.Map;

import com.amazon.device.ads.AdSize;
import com.mopub.mobileads.AmazonAdBanner;
import com.mopub.mobileads.MoPubErrorCode;
import com.mopub.mobileads.MoPubInterstitial;
import com.mopub.mobileads.MoPubView;
import com.mopub.mobileads.MoPubInterstitial.InterstitialAdListener;
import com.mopub.mobileads.MoPubView.BannerAdListener;

import android.app.Activity;
import android.content.Context;
import android.os.Handler;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout.LayoutParams;

/**
 * Mopub的JNI相关方法的Java端实现
 * 
 * @author Steven.Xc.Tian
 */
public class STMopubAds extends STAds implements InterstitialAdListener,
		BannerAdListener {
	/**
	 * 映射{@link com.amazon.device.ads.AdSize}的广告类型大小
	 * 
	 * @author Steven.Xc.Tian
	 * 
	 */
	public enum STAmazonAdSize {
		SIZE_300x50, SIZE_320x50, SIZE_300x250, SIZE_600x90, SIZE_728x90, SIZE_1024x50, SIZE_AUTO
	}

	private static final String TAG = "STMopubAds";

	protected static final String PHONE_BANNER_KEY = "MoPub_phone_banner";
	protected static final String TABLET_BANNER_KEY = "MoPub_tablet_banner";
	protected static final String PHONE_FULL_SCREEN_KEY = "MoPub_phone_fullscreen";
	protected static final String TABLET_FULL_SCREEN_KEY = "MoPub_tablet_fullscreen";
	protected static final String TABLET_CROSSPROMO_KEY = "MoPub_tablet_crosspromo";
	protected static final String PHONE_CROSSPROMO_KEY = "MoPub_phone_crosspromo";
	protected static final String PHONE_RECT_KEY = "MoPub_phone_rect";
	protected static final String TABLET_RECT_KEY = "MoPub_tablet_rect";

	private MoPubInterstitial stInterstitialView;
	private MoPubView stBannerView;
	private MoPubView stRectBannerView;
	private static STMopubAds mInstance;

	// when call removeAds() method, set this flag true
	private boolean isBannerAdRemoved = false;
	private boolean isRectAdRemoved = false;

	private boolean isInterstitialAdVisible = true;

	boolean isRectVisable = false;
	private Map<String, Object> localExtras = null;

	/**
	 * @return 可能会返回null,需要先调用{@link #setup(Context, boolean)}
	 */
	public static STMopubAds getInstance() {
		return mInstance;
	}

	/**
	 * 设置广告JNI相关环境
	 * 
	 * @param context
	 *            Context
	 * @param debug
	 *            boolean 是否开启debug模式
	 */
	public static void setup(final Context context, boolean debug) {
		if (mInstance == null) {
			mInstance = new STMopubAds(context, debug);
		}
	}

	private STMopubAds(Context context, boolean debug) {
		super(context, debug);

		bannerAdViewLayoutParams = new LayoutParams(
				(int) (300 * densityScale), (int) (50 * densityScale),
				Gravity.BOTTOM);

		// //////////////////////////////////////
		// init banner view
		stBannerView = new MoPubView(stContext);

		if (isTablet) {
			stBannerView.setAdUnitId(getMetaData(TABLET_BANNER_KEY));
		} else {
			stBannerView.setAdUnitId(getMetaData(PHONE_BANNER_KEY));
		}

		localExtras = new HashMap<String, Object>();
		localExtras.put(AmazonAdBanner.STR_ADSIZE, AdSize.SIZE_AUTO);
		stBannerView.setLocalExtras(localExtras);

		stBannerView.setBannerAdListener(STMopubAds.this);

		// //////////////////////////////////////
		// init interstitial view
		if (isTablet) {
			stInterstitialView = new MoPubInterstitial((Activity) stContext,
					getMetaData(TABLET_FULL_SCREEN_KEY));
		} else {
			stInterstitialView = new MoPubInterstitial((Activity) stContext,
					getMetaData(PHONE_FULL_SCREEN_KEY));
		}

		stInterstitialView.setInterstitialAdListener(STMopubAds.this);
	}

	/**
	 * 设置Amazon广告的大小类型, 默认tablet为SIZE_600x90，phone为SIZE_300x50
	 * <p>
	 * <b>NOTE：需要在 {@link #requestAds()}之前调用</b>
	 * </p>
	 * 
	 * @param tabletSize
	 *            STAmazonAdSize tablet的尺寸
	 * @param phoneSize
	 *            STAmazonAdSize phone的尺寸
	 * @see STAmazonAdSize
	 */
	public void setAmazonSizeType(STAmazonAdSize tabletSize,
			STAmazonAdSize phoneSize) {
		if (localExtras == null) {
			localExtras = new HashMap<String, Object>();
		} else {
			localExtras.clear();
		}

		STAmazonAdSize temSize = isTablet ? tabletSize : phoneSize;

		switch (temSize) {
		case SIZE_300x50:
			localExtras.put(AmazonAdBanner.STR_ADSIZE, AdSize.SIZE_300x50);
			break;
		case SIZE_320x50:
			localExtras.put(AmazonAdBanner.STR_ADSIZE, AdSize.SIZE_320x50);
			break;
		case SIZE_300x250:
			localExtras.put(AmazonAdBanner.STR_ADSIZE, AdSize.SIZE_300x250);
			break;
		case SIZE_600x90:
			localExtras.put(AmazonAdBanner.STR_ADSIZE, AdSize.SIZE_600x90);
			break;
		case SIZE_728x90:
			localExtras.put(AmazonAdBanner.STR_ADSIZE, AdSize.SIZE_728x90);
			break;
		case SIZE_1024x50:
			localExtras.put(AmazonAdBanner.STR_ADSIZE, AdSize.SIZE_1024x50);
			break;
		default:
			// SIZE_AUTO
			localExtras.put(AmazonAdBanner.STR_ADSIZE, AdSize.SIZE_AUTO);
			break;
		}

		stBannerView.setLocalExtras(localExtras);
	}

	/**
	 * @see common.jni.ads.STAds#disposal()
	 */
	@Override
	protected void disposal() {
		if (stBannerView != null) {
			stBannerView.destroy();
			stBannerView = null;
		}

		if (stRectBannerView != null) {
			stRectBannerView.destroy();
			stRectBannerView = null;
		}

		if (stInterstitialView != null) {
			stInterstitialView.destroy();
			stInterstitialView = null;
		}
	}

	@Override
	public void requestAds() {
		isBannerAdRemoved = false;

		((Activity) stContext).runOnUiThread(new Runnable() {

			@Override
			public void run() {
				stBannerView.loadAd();
			}
		});
	}

	@Override
	public void requestAds(final String phoneBannerId,
			final String tabletBannerId) {

		((Activity) stContext).runOnUiThread(new Runnable() {

			@Override
			public void run() {
				if (stBannerView == null) {
					stBannerView = new MoPubView(stContext);

					localExtras = new HashMap<String, Object>();
					localExtras
							.put(AmazonAdBanner.STR_ADSIZE, AdSize.SIZE_AUTO);
					stBannerView.setLocalExtras(localExtras);

					stBannerView.setBannerAdListener(STMopubAds.this);
				}

				if (isTablet) {
					stBannerView.setAdUnitId(tabletBannerId);
				} else {
					stBannerView.setAdUnitId(phoneBannerId);
				}

				requestAds();
			}
		});
	}

	/**
	 * @see common.jni.ads.STAds#requestRectAds()
	 */
	@Override
	public void requestRectAds() {
		isRectAdRemoved = false;
		isRectVisable = true;

		((Activity) stContext).runOnUiThread(new Runnable() {

			@Override
			public void run() {

				if (stRectBannerView == null) {
					stRectBannerView = new MoPubView(stContext);

					if (isTablet) {
						stRectBannerView
								.setAdUnitId(getMetaData(TABLET_RECT_KEY));
					} else {
						stRectBannerView
								.setAdUnitId(getMetaData(PHONE_RECT_KEY));
					}

					localExtras = new HashMap<String, Object>();
					localExtras.put(AmazonAdBanner.STR_ADSIZE,
							AdSize.SIZE_300x250);
					stRectBannerView.setLocalExtras(localExtras);

					stRectBannerView.setBannerAdListener(STMopubAds.this);

					//
					rectAdViewLayoutParams = new LayoutParams(
							(int) (300 * densityScale),
							(int) (250 * densityScale), Gravity.CENTER);
				}

				stRectBannerView.loadAd();
			}
		});
	}

	/**
	 * @see common.jni.ads.STAds#requestRectAds(String, String)
	 */
	@Override
	public void requestRectAds(final String phoneRectId,
			final String tabletRectId) {
		isRectAdRemoved = false;
		isRectVisable = true;

		((Activity) stContext).runOnUiThread(new Runnable() {

			@Override
			public void run() {
				if (stRectBannerView == null) {
					stRectBannerView = new MoPubView(stContext);

					if (isTablet) {
						stRectBannerView.setAdUnitId(tabletRectId);
					} else {
						stRectBannerView.setAdUnitId(phoneRectId);
					}

					localExtras = new HashMap<String, Object>();
					localExtras.put(AmazonAdBanner.STR_ADSIZE,
							AdSize.SIZE_300x250);
					stRectBannerView.setLocalExtras(localExtras);

					stRectBannerView.setBannerAdListener(STMopubAds.this);

					//
					rectAdViewLayoutParams = new LayoutParams(
							(int) (300 * densityScale),
							(int) (250 * densityScale), Gravity.CENTER);
				}

				stRectBannerView.loadAd();
			}
		});
	}

	/**
	 * @see common.jni.ads.STAds#requestInterstitialAds()
	 */
	@Override
	public void requestInterstitialAds() {
		if (isInterstitialAdShowing)
			return;

		((Activity) stContext).runOnUiThread(new Runnable() {

			@Override
			public void run() {
				loadInterstitialAds(getInterstitialAdsId(AdsType.ADS_INTERSTITIAL));
			}
		});

	}

	@Override
	public void requestInterstitialAds(final String phoneId,
			final String tabletId) {
		if (isInterstitialAdShowing)
			return;
		((Activity) stContext).runOnUiThread(new Runnable() {

			@Override
			public void run() {

				if (isTablet) {
					loadInterstitialAds(tabletId);
				} else {
					loadInterstitialAds(phoneId);
				}

			}
		});

	}

	/**
	 * @see common.jni.ads.STAds#removeAds()
	 */
	@Override
	public void removeAds() {
		// 改变状态
		isBannerAdRemoved = true;

		((Activity) stContext).runOnUiThread(new Runnable() {

			@Override
			public void run() {
				adViewContainer.removeView(stBannerView);
			}
		});
	}

	@Override
	public void removeRectAds() {
		isRectAdRemoved = true;
		isRectVisable = false;

		((Activity) stContext).runOnUiThread(new Runnable() {

			@Override
			public void run() {
				adViewContainer.removeView(stRectBannerView);
			}
		});
	}

	/**
	 * @see common.jni.ads.STAds#setAdsVisibility(boolean)
	 */
	@Override
	public void setAdsVisibility(boolean visibility) {

		final int visi = visibility ? View.VISIBLE : View.INVISIBLE;
		((Activity) stContext).runOnUiThread(new Runnable() {

			@Override
			public void run() {
				if (stBannerView != null)
					stBannerView.setVisibility(visi);
			}
		});
	}

	@Override
	public void setRectAdsVisibility(boolean visibility) {
		isRectVisable = visibility;
		final int visi = visibility ? View.VISIBLE : View.INVISIBLE;
		((Activity) stContext).runOnUiThread(new Runnable() {

			@Override
			public void run() {
				if (stRectBannerView != null)
					stRectBannerView.setVisibility(visi);

			}
		});

	}
	
	@Override
	public void setInterstitialAdsVisibility(boolean visibility) {
		isInterstitialAdVisible = visibility;

		if (isInterstitialAdVisible && stInterstitialView != null
				&& stInterstitialView.isReady()) {
			((Activity) stContext).runOnUiThread(new Runnable() {

				@Override
				public void run() {
					stInterstitialView.show();
				}
			});
		}
	}

	@Override
	public void requestInterstitialAds(final int type) {
		if (isInterstitialAdShowing)
			return;

		((Activity) stContext).runOnUiThread(new Runnable() {

			@Override
			public void run() {
				loadInterstitialAds(getInterstitialAdsId(type));
			}
		});
	}

	/**
	 * 加载全屏或cross promo 广告
	 * 
	 * @param AdsId
	 */
	private void loadInterstitialAds(String AdsId) {

		if (stInterstitialView != null)
			stInterstitialView.destroy();
		if (AdsId != null) {
			stInterstitialView = new MoPubInterstitial((Activity) stContext,
					AdsId);

			stInterstitialView.setInterstitialAdListener(STMopubAds.this);
			stInterstitialView.load();
		} else {
			Log.e("", "loadInterstitialAds() error,AdsId is null!");
		}
	}

	/**
	 * 从manifest文件中获取广告ID
	 * 
	 * @param type
	 * @return
	 */
	private String getInterstitialAdsId(int type) {
		String adsId = null;
		if (type == AdsType.ADS_INTERSTITIAL) {
			if (isTablet) {
				adsId = getMetaData(TABLET_FULL_SCREEN_KEY);
			} else {
				adsId = getMetaData(PHONE_FULL_SCREEN_KEY);
			}
		} else if (type == AdsType.ADS_CROSSPROMO) {
			if (isTablet) {
				adsId = getMetaData(TABLET_CROSSPROMO_KEY);
			} else {
				adsId = getMetaData(PHONE_CROSSPROMO_KEY);
			}
		} else {
			Log.e("", "getInterstitialAdsId() error,unknow ads type!");
		}
		return adsId;
	}


	@Override
	public void onBannerClicked(MoPubView arg0) {
		if (debug)
			Log.e(TAG, "TEST_ADS onBannerClicked!");

		((Activity) stContext).runOnUiThread(new Runnable() {

			@Override
			public void run() {
				nativeClickedBannerAd();
			}
		});

	}

	@Override
	public void onBannerCollapsed(MoPubView arg0) {
		if (debug)
			Log.e(TAG, "TEST_ADS onBannerCollapsed!");
	}

	@Override
	public void onBannerExpanded(MoPubView arg0) {
		if (debug)
			Log.e(TAG, "TEST_ADS onBannerExpanded!");
		
	}

	@Override
	public void onBannerFailed(MoPubView arg0, MoPubErrorCode arg1) {
		if (debug && (arg0 == stBannerView))
			Log.d(TAG, "TEST_ADS Banner Ad onBannerFailed!" + arg1);

		if (debug && (arg0 == stRectBannerView))
			Log.d(TAG, "TEST_ADS Rect Ad onBannerFailed!");

		// 通知底层
		nativeAdLoadFailed(arg1.ordinal());
	}

	@Override
	public void onBannerLoaded(MoPubView arg0) {

		if (arg0 == stBannerView) {
			// banner ad is loaded.
			if (debug)
				Log.d(TAG, "TEST_ADS Banner Ad onBannerLoaded!");

			// banner广告加载成功时，已经执行了移除广告操作
			if (!isBannerAdRemoved) {
				if (stBannerView.getParent() == null) {
					((Activity) stContext).runOnUiThread(new Runnable() {

						@Override
						public void run() {
							adViewContainer.addView(stBannerView,
									bannerAdViewLayoutParams);
							// 通知底层
							nativeAdLoadSuccessfully();
						}
					});
				} else {
					// just refresh the ads
					// 通知底层
					nativeAdLoadSuccessfully();
				}
			}
		} else if (arg0 == stRectBannerView) {
			// rect ad is loaded.
			if (debug)
				Log.d(TAG, "TEST_ADS Rect Ad onBannerLoaded!");

			// rect广告加载成功时，已经执行了移除广告操作
			if (!isRectAdRemoved) {

				if (stRectBannerView.getParent() == null) {
					((Activity) stContext).runOnUiThread(new Runnable() {

						@Override
						public void run() {
							adViewContainer.addView(stRectBannerView,
									rectAdViewLayoutParams);
							// 通知底层
							nativeAdLoadSuccessfully();

							if (!isRectVisable)
								stRectBannerView.setVisibility(View.INVISIBLE);
						}
					});
				} else {
					// just refresh the ads
					// 通知底层
					nativeAdLoadSuccessfully();
				}
			}
		}
	}

	/**
	 * 在广告的Activity销毁后，也即在被覆盖的游戏Activity重新执行了onResume()方法后被调用
	 */
	@Override
	public void onInterstitialDismissed(MoPubInterstitial arg0) {
		if (debug)
			Log.d(TAG, "==onInterstitialDismissed!");

		// 为了解决Admob全屏广告重复加载的问题
		Handler handler=new Handler();
		handler.postDelayed(new Runnable() {
			@Override
			public void run() {
				isInterstitialAdShowing = false;
			}
		}, 300);
		nativeInterstitialAdDismissed();
	}

	@Override
	public void onInterstitialFailed(MoPubInterstitial arg0, MoPubErrorCode arg1) {
		if (debug)
			Log.d(TAG, "==onInterstitialFailed!");

		nativeInterstitialAdFailed(arg1.ordinal());
	}

	/**
	 * 当全屏广告加载成功，调用这个方法后，广告自身的Activity会将当前游戏Activity覆盖，
	 * 即游戏Activity会调用onPause()方法。
	 */
	@Override
	public void onInterstitialLoaded(MoPubInterstitial arg0) {
		if (debug)
			Log.d(TAG, "==onInterstitialLoaded!");
		nativeInterstitialAdLoaded();

		setInterstitialAdsVisibility(isInterstitialAdVisible);
	}

	@Override
	public void onInterstitialShown(MoPubInterstitial arg0) {
		if (debug)
			Log.d(TAG, "==onInterstitialShown!");
		isInterstitialAdShowing = true;
		nativeInterstitialAdShown();
	}

	@Override
	public void onInterstitialClicked(MoPubInterstitial interstitial) {
		if (debug)
			Log.d(TAG, "==onInterstitialClicked!");
	}

	
}
