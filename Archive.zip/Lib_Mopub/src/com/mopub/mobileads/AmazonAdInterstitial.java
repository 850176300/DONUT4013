package com.mopub.mobileads;

import java.util.Map;

import com.amazon.device.ads.Ad;
import com.amazon.device.ads.AdError;
import com.amazon.device.ads.AdProperties;
import com.amazon.device.ads.AdRegistration;
import com.amazon.device.ads.DefaultAdListener;
import com.amazon.device.ads.InterstitialAd;

import android.app.Activity;
import android.content.Context;
import android.util.Log;

public class AmazonAdInterstitial extends CustomEventInterstitial{

	private InterstitialAd interstitial;
	CustomEventInterstitialListener interstitialListener;
	@Override
	protected void loadInterstitial(Context context,
			CustomEventInterstitialListener customEventInterstitialListener,
			Map<String, Object> localExtras, Map<String, String> serverExtras) {
		interstitialListener = customEventInterstitialListener;
		interstitial = new InterstitialAd((Activity)context);
		interstitial.setListener(new AdsListener());

		String appKey = serverExtras.get("AppKey");
		if(appKey==null||"".equals(appKey))
		{
			customEventInterstitialListener.onInterstitialFailed(MoPubErrorCode.ADAPTER_CONFIGURATION_ERROR);
            return;
		}
		String mode = serverExtras.get("Mode");
		if (mode != null && mode.equals("Test")) {
			AdRegistration.enableTesting(true);
			AdRegistration.enableLogging(true);
		}
		AdRegistration.enableLogging(true);
		AdRegistration.enableTesting(true);
		AdRegistration.setAppKey(appKey); 
		interstitial.loadAd();
	}

	@Override
	protected void showInterstitial() {
		if(interstitial!=null)
		{
			interstitial.showAd();
		}
	}

	@Override
	protected void onInvalidate() {
		interstitial=null;
	}
	
	private class AdsListener extends DefaultAdListener{
		
		@Override
        public void onAdLoaded(Ad ad, AdProperties adProperties)
        {
			interstitialListener.onInterstitialLoaded();
        }
 
        @Override
        public void onAdFailedToLoad(Ad ad, AdError error)
        {

        	switch(error.getCode()){
        	case INTERNAL_ERROR:
        		interstitialListener.onInterstitialFailed(MoPubErrorCode.INTERNAL_ERROR);
        		break;
        	case NETWORK_ERROR:
        		interstitialListener.onInterstitialFailed(MoPubErrorCode.NETWORK_INVALID_STATE);
        		break;
        	case NETWORK_TIMEOUT:
        		interstitialListener.onInterstitialFailed(MoPubErrorCode.NETWORK_TIMEOUT);
        		break;
        	case NO_FILL:
        		interstitialListener.onInterstitialFailed(MoPubErrorCode.NO_FILL);
        		break;
        	default:
        		interstitialListener.onInterstitialFailed(MoPubErrorCode.UNSPECIFIED);
        	}
        }
 
        @Override
        public void onAdDismissed(Ad ad)
        {
        	interstitialListener.onInterstitialDismissed();
        }
	}

}
