package com.mopub.mobileads;

import java.util.Map;

import android.app.Activity;
import android.content.Context;
import android.util.Log;

import com.amazon.device.ads.Ad;
import com.amazon.device.ads.AdError;
import com.amazon.device.ads.AdLayout;
import com.amazon.device.ads.AdListener;
import com.amazon.device.ads.AdProperties;
import com.amazon.device.ads.AdRegistration;
import com.amazon.device.ads.AdSize;
import com.amazon.device.ads.AdTargetingOptions;

public class AmazonAdBanner extends CustomEventBanner implements AdListener {
	public static String STR_ADSIZE="adSize";
	private CustomEventBannerListener mBannerListener;
	private AdLayout adLayout;

	@Override
	protected void loadBanner(Context context, CustomEventBannerListener customEventBannerListener, Map<String, Object> localExtras, Map<String, String> serverExtras) {
		mBannerListener = customEventBannerListener;
		String appKey = serverExtras.get("AppKey");
		
		if(appKey==null||"".equals(appKey))
		{
			mBannerListener.onBannerFailed(MoPubErrorCode.ADAPTER_CONFIGURATION_ERROR);
            return;
		}
		
		Object _adsize=localExtras.get(STR_ADSIZE);
		if(_adsize==null)
		{
			Log.w("AmazonAdBanner", "Not set AdSize!");
			adLayout = new AdLayout((Activity) context,AdSize.SIZE_AUTO);
		}else
		{
			adLayout = new AdLayout((Activity) context,(AdSize)_adsize);
		}
		
		AdRegistration.setAppKey(appKey);
		String mode = serverExtras.get("Mode");
		if (mode != null && mode.equals("Test")) {
			AdRegistration.enableTesting(true);
			AdRegistration.enableLogging(true);
		}
		
		adLayout.setListener(this);
		adLayout.loadAd(new AdTargetingOptions());
		mBannerListener.onBannerLoaded(adLayout);
	}

	@Override
	protected void onInvalidate() {
		adLayout.setListener(null);
		adLayout.destroy();
		adLayout=null;
	}

	@Override
	public void onAdCollapsed(Ad  arg0) {
	}

	@Override
	public void onAdExpanded(Ad arg0) {
	}

	@Override
	public void onAdFailedToLoad(Ad arg0, AdError error) {
		Log.i("", "======amazon banner========>>"+error.getCode().name());
		switch(error.getCode())
		{
		case INTERNAL_ERROR:
			mBannerListener.onBannerFailed(MoPubErrorCode.INTERNAL_ERROR);
			break;
		case NETWORK_ERROR:
			mBannerListener.onBannerFailed(MoPubErrorCode.NETWORK_INVALID_STATE);
			break;
		case NO_FILL:
			mBannerListener.onBannerFailed(MoPubErrorCode.NO_FILL);
			break;
		default:
			mBannerListener.onBannerFailed(MoPubErrorCode.UNSPECIFIED);
		}
	}

	@Override
	public void onAdLoaded(Ad arg0, AdProperties arg1) {
		mBannerListener.onBannerLoaded(adLayout);
	}


	@Override
	public void onAdDismissed(Ad arg0) {
		
	}





}
