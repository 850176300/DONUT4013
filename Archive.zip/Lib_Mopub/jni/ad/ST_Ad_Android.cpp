/*
 * ST_Ad_Android.cpp
 *
 *  Created on: 2013-9-2
 *      Author: Steven.Xc.Tian
 */

#include "ST_Ad_Android.h"

static AndroidAdManager* sp_AndroidAdManager = 0;

AndroidAdManager* AndroidAdManager::getInstance()
{
	if (!sp_AndroidAdManager)
	{
		sp_AndroidAdManager = new AndroidAdManager();
	}

	return sp_AndroidAdManager;
}

void AndroidAdManager::destroy()
{
	if (sp_AndroidAdManager)
	{
		delete sp_AndroidAdManager;

		sp_AndroidAdManager = 0;
	}
}

bool AndroidAdManager::init(JNIEnv * pEnv, jobject pAdJava)
{
	// get class
	ClassAds = pEnv->GetObjectClass(pAdJava);
	if (!ClassAds)
	{
		LOGE("get STAds class Failed!");
		return false;
	}
	ClassAds = (jclass) ST_JNI_Helper::makeGlobalRef(pEnv, ClassAds);

	// get method id --- purchaseManaged(String)
	MethodRequestAds = pEnv->GetMethodID(ClassAds, "requestAds", "()V");
	if (!MethodRequestAds)
	{
		LOGE("get Method requestAds id Failed!");
		return false;
	}

	MethodRequestInterstitialAds = pEnv->GetMethodID(ClassAds, "requestInterstitialAds", "()V");
	if (!MethodRequestInterstitialAds)
	{
		LOGE("get Method requestInterstitialAds id Failed!");
		return false;
	}
	MethodRequestInterstitialAdsForType = pEnv->GetMethodID(ClassAds, "requestInterstitialAds", "(I)V");

	if (!MethodRequestInterstitialAdsForType)
	{
		cocos2d::log("get Method MethodRequestInterstitialAdsForType id Failed!");
		return false;
	}

	// get method id --- purchaseUnmanaged(String)
	MethodRemoveAds = pEnv->GetMethodID(ClassAds, "removeAds", "()V");
	if (!MethodRemoveAds)
	{
		LOGE("get Method removeAds id Failed!");
		return false;
	}

	MethodSetAdsVisibility = pEnv->GetMethodID(ClassAds, "setAdsVisibility", "(Z)V");
	if (!MethodSetAdsVisibility)
	{
		LOGE("get Method removeAds id Failed!");
		return false;
	}

	// Caches objects.
	stAdsJava = ST_JNI_Helper::makeGlobalRef(pEnv, pAdJava);
	if (!stAdsJava)
	{
		LOGE("Cache stIABJava Failed!");
		return false;
	}

	return true;
}

void AndroidAdManager::setAdDelegate(STAdsDelegate* pAdDelegate)
{
	st_m_AdsDelegate = pAdDelegate;
}

void AndroidAdManager::requestAds()
{
	if (!stAdsJava)
	{
		LOGE("STAds::requestAds() failed!");
		return;
	}

	JNIEnv* lEnv = ST_JNI_Helper::getJNIEnv();

	lEnv->CallVoidMethod(stAdsJava, MethodRequestAds);
}

void AndroidAdManager::requestInterstitialAds()
{
	if (!stAdsJava)
	{
		LOGE("STAds::requestInterstitialAds() failed!");
		return;
	}

	JNIEnv* lEnv = ST_JNI_Helper::getJNIEnv();

	lEnv->CallVoidMethod(stAdsJava, MethodRequestInterstitialAds);
}
void AndroidAdManager::requestInterstitialAds(int type)
{
	if (!stAdsJava)
	{
		LOGE("STAds::requestInterstitialAds() failed!");
		return;
	}

	JNIEnv* lEnv = ST_JNI_Helper::getJNIEnv();

	lEnv->CallVoidMethod(stAdsJava, MethodRequestInterstitialAdsForType,type);
}
void AndroidAdManager::removeAds()
{
	if (!stAdsJava)
	{
		LOGE("STAds::removeAds() failed!");
		return;
	}

	JNIEnv* lEnv = ST_JNI_Helper::getJNIEnv();

	lEnv->CallVoidMethod(stAdsJava, MethodRemoveAds);
}

void AndroidAdManager::setAdsVisibility(bool visibility)
{
	if (!stAdsJava)
	{
		LOGE("STAds::setAdsVisibility(bool) failed!");
		return;
	}

	JNIEnv* lEnv = ST_JNI_Helper::getJNIEnv();

	lEnv->CallVoidMethod(stAdsJava, MethodSetAdsVisibility, visibility);
}

/*============================================*/
void AndroidAdManager::onBannerLoadSuccessfully()
{
	if (st_m_AdsDelegate)
	{
		st_m_AdsDelegate->onBannerLoadSuccessfully();
	}
}

void AndroidAdManager::onBannerLoadFailed(int errorCode)
{
	if (st_m_AdsDelegate)
	{
		st_m_AdsDelegate->onBannerLoadFailed(errorCode);
	}
}

void AndroidAdManager::onBannerClicked()
{
	if (st_m_AdsDelegate)
	{
		st_m_AdsDelegate->onBannerClicked();
	}
}

void AndroidAdManager::onBannerDismissed()
{
	if (st_m_AdsDelegate)
	{
		st_m_AdsDelegate->onBannerDismissed();
	}
}

void AndroidAdManager::onInterstitialAdLoaded()
{
	if (st_m_AdsDelegate)
	{
		st_m_AdsDelegate->onInterstitialAdLoaded();
	}
}

void AndroidAdManager::onInterstitialAdFailed(int errorCode)
{
	if (st_m_AdsDelegate)
	{
		st_m_AdsDelegate->onInterstitialAdFailed(errorCode);
	}
}

void AndroidAdManager::onInterstitialShown()
{
	if (st_m_AdsDelegate)
	{
		st_m_AdsDelegate->onInterstitialShown();
	}
}

void AndroidAdManager::onInterstitialDismissed()
{
	if (st_m_AdsDelegate)
	{
		st_m_AdsDelegate->onInterstitialDismissed();
	}
}

AndroidAdManager::~AndroidAdManager()
{
	ST_JNI_Helper::deleteGlobalRef(ClassAds);
	ST_JNI_Helper::deleteGlobalRef(stAdsJava);
}

