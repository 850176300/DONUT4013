/*
 * ST_Ad_Android.h
 *
 *  Created on: 2013-9-2
 *      Author: Steven.Xc.Tian
 */

#ifndef ST_AD_ANDROID_H_
#define ST_AD_ANDROID_H_

#include "../ST_JNI_Helper.h"
#include "STAdsDelegate.h"

class AndroidAdManager: public STAdsDelegate
{
	STAdsDelegate* st_m_AdsDelegate;
public:
	AndroidAdManager() :
			st_m_AdsDelegate(0), stAdsJava(0), ClassAds(0), MethodRequestAds(0), MethodRemoveAds(0), MethodRequestInterstitialAds(
					0), MethodSetAdsVisibility(0)
	{
	}
	~AndroidAdManager();

	static AndroidAdManager* getInstance();

	static void destroy();

	bool init(JNIEnv * pEnv, jobject pAdJava);

	void setAdDelegate(STAdsDelegate* pAdDelegate);

public:
	void requestAds();

	/**
	 * 请求普通全屏广告
	 */
	void requestInterstitialAds();
	/**
	 * 更加类型请求全屏广告，0为普通全屏，1为cross promo
	 */
	void requestInterstitialAds(int type);
	void removeAds();

	void setAdsVisibility(bool visibility);

public:
	/* the below methods derived from STAdsDelegate */

	void onBannerLoadSuccessfully();

	void onBannerLoadFailed(int errorCode);

	void onBannerClicked();

	void onBannerDismissed();

	void onInterstitialAdLoaded();

	void onInterstitialAdFailed(int errorCode);

	void onInterstitialShown();

	void onInterstitialDismissed();

private:
	/*>>>>>>>> below declaration is used by jni <<<<<<<<*/
	// Cached Classes.
	jclass ClassAds;
	// Cached java object
	jobject stAdsJava;
	// Cached active Methods.
	jmethodID MethodRequestAds;
	jmethodID MethodRemoveAds;
	jmethodID MethodRequestInterstitialAds;
	jmethodID MethodRequestInterstitialAdsForType;
	jmethodID MethodSetAdsVisibility;
};

#endif /* ST_AD_ANDROID_H_ */
