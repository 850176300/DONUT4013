/*
 * STAds.cpp
 *
 *  Created on: 2013-9-2
 *      Author: Steven.Xc.Tian
 */
#include "STAds.h"
#include "ST_Ad_Android.h"

bool STAds::willShowAd = true;
bool STAds::interstitialShown = false;
bool STAds::bannerAdVisibility = false;

void STAds::requestAds()
{
	AndroidAdManager::getInstance()->requestAds();
}

void STAds::removeAds()
{
	AndroidAdManager::getInstance()->removeAds();
}

void STAds::requestInterstitialAds()
{
	AndroidAdManager::getInstance()->requestInterstitialAds();
}
void STAds::requestInterstitialAds(int type)
{

	AndroidAdManager::getInstance()->requestInterstitialAds(type);
}

void STAds::setAdsDelegate(STAdsDelegate* delegate)
{
	AndroidAdManager::getInstance()->setAdDelegate(delegate);
}

void STAds::setAdsVisibility(bool visibility)
{
    bannerAdVisibility = visibility;
	AndroidAdManager::getInstance()->setAdsVisibility(visibility);
}

void STAds::destroy()
{
	AndroidAdManager::getInstance()->destroy();
}

STAds::STAds()
{
}

STAds::~STAds()
{
}
