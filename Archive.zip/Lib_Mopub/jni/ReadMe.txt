这里只有Android端的JNI方法及实现，IOS的实现不在这里。请移步Android Common下的IOS目录查找

1. 将 jni/ad 目录下的 STAdsDelegate.h 和 STAds.h 放到 cocos2d-x 工程的 Classes 目录下，IOS 和 Android 共用这两个头文件。 
2. 将其余文件复制到自己Android工程的jni目录下。
3. ST_JNI_Helper.h 和 ST_JNI_Helper.cpp 为通用类，在自己工程中只需要一个即可。