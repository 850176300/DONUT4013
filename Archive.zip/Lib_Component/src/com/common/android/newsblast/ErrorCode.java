package com.common.android.newsblast;

public enum ErrorCode {
	
	unknowError,
	networkError;

}
