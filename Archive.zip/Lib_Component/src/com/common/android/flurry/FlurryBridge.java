package com.common.android.flurry;

import java.util.Map;

import android.content.Context;

import com.flurry.android.FlurryAgent;

public class FlurryBridge {
    
    private static FlurryBridge mFlurryBridgeInstance = null;
    public static FlurryBridge getInstance() {
        if(null == mFlurryBridgeInstance) mFlurryBridgeInstance = new FlurryBridge();
        return mFlurryBridgeInstance;
    }
    private FlurryBridge() {
    }
    
    public void setup(Context ctx) {
        nativeInit();
    }
    
    public void destory() {
        nativeFinalize();
    }
    
    public void nativeOnEvent(String eventId) {
        FlurryAgent.onEvent(eventId);
    }
    
    public void nativeOnEvent(String eventId, Map<String, String> parameters) {
        FlurryAgent.onEvent(eventId, parameters);
    }
    
    public void nativeOnError(String eventId, String message, String errorClass) {
        FlurryAgent.onError(eventId, message, errorClass);
    }
    
    public void nativeLogEvent(String eventId) {
        FlurryAgent.logEvent(eventId);
    }
    
    public void nativeLogEvent(String eventId, Map<String, String> parameters) {
        FlurryAgent.logEvent(eventId, parameters);
    }
    
    public void nativeLogEvent(String eventId, boolean timed) {
        FlurryAgent.logEvent(eventId, timed);
    }
    
    public void nativeLogEvent(String eventId, Map<String, String> parameters, boolean timed) {
        FlurryAgent.logEvent(eventId, parameters, timed);
    }
    
    // native methods
    private native void nativeInit();
    private native void nativeFinalize();
}