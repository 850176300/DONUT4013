package com.common.android;

public class PlatformCode {
	
	public static final int GOOGLEPLAY=32;
	public static final int AMAZON=33;
	public static final int SAMSUNG=34;

}
