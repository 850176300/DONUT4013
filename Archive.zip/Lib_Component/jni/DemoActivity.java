/****************************************************************************
Copyright (c) 2010-2011 cocos2d-x.org

http://www.cocos2d-x.org

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.
 ****************************************************************************/
package net.bigbearentertainment.android_ho_kitchen;

import org.cocos2dx.lib.Cocos2dxActivity;
import org.cocos2dx.lib.Cocos2dxGLSurfaceView;

import com.common.android.IapResult;
import com.common.android.OnSetupListener;
import com.common.android.PlatformCode;
import com.common.android.jni.MoreGamesActivityForJNI;
import com.common.android.jni.STMopubAds;
import com.common.android.jni.STMopubAds.STAmazonAdSize;
import com.common.android.newsblast.NewsBlast;
import com.common.android.utils.Utils;
import com.diwublog.AnalyticX.AnalyticXBridge;

import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;

public class HIDD_BIGB02 extends Cocos2dxActivity {
	private NewsBlast mNewsBlast;

	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		// 只有Google Play需要设置IAP的public key
		if (getPlatformCode() == PlatformCode.GOOGLEPLAY) {
			setPublicKey("your public key");
		}

		setSetupBillingListener(new OnSetupListener() {

			@Override
			public void onIabSetupFinished(IapResult result) {
				// 当Billing环境配置完成后，会调用此接口，所有购买操作应当在Billing环境配置成功后才能调用

				if (result.isSuccess()) {
					if (getDebugMode())
						Log.i("", "=======Billing support======");
				} else {
					if (getDebugMode())
						Log.i("", "=======Billing unsupported======");
				}

			}
		});

		onStartSetupBilling();

		// 初始化JNI环境
		setupNativeEnvironment();

		// 初始化JNI广告模块
		STMopubAds.setup(this, true, Utils.getMetaData(this, "MoPub_phone_banner"),
				Utils.getMetaData(this, "MoPub_phone_fullscreen"), Utils.getMetaData(this, "MoPub_tablet_banner"),
				Utils.getMetaData(this, "MoPub_tablet_fullscreen"));
		// 如果有Amazon广告，设置Amazon广告大小
		STMopubAds.getInstance().setAmazonSizeType(STAmazonAdSize.SIZE_300x250, STAmazonAdSize.SIZE_300x250);
		// 设置广告Banner大小和位置
		STMopubAds.getInstance().setBannnerAdViewLayoutParams(300, 250, Gravity.CENTER);

		// flurry jni
		AnalyticXBridge.sessionContext = this.getApplicationContext();

		// 尽快弹出rate us对话框
		setRateUsTime(20);

		// 设置more game里的layout id
		MoreGamesActivityForJNI.ACTIVITY_LAYOUT_ID = R.layout.activity_more_games;
		MoreGamesActivityForJNI.WEBVIEW_ID = R.id.more_game_view;
		MoreGamesActivityForJNI.TITLE_PROGRESS_ID = R.id.title_progress;

		// 初始 newsblast
		mNewsBlast = new NewsBlast(this, getPlatformCode());
	}

	@Override
	protected void onResume() {
		super.onResume();

		// 确保锁屏状态下不会重复调用
		if (!islock) {
			// 每次resume时重新请求 newsblast
			if (!STMopubAds.isInterstitialAdShown) {
				mNewsBlast.continueNews();
				mNewsBlast.doNewsBlast_always();
			} else {
				STMopubAds.isInterstitialAdShown = false;
			}
		}
	}

	@Override
	protected void onPause() {
		mNewsBlast.breakOff();
		super.onPause();
	}

	@Override
	protected void onStartSession() {
		// 屏蔽父类方法，Flurry的初始化交由C++层初始化
		// super.onStartSession();
	}

	@Override
	public int getPlatformCode() {
		return PlatformCode.AMAZON;
	}

	@Override
	public boolean getDebugMode() {
		return true;
	}

	@Override
	public boolean enableEvent() {
		return false;
	}

	public Cocos2dxGLSurfaceView onCreateView() {
		Cocos2dxGLSurfaceView glSurfaceView = new Cocos2dxGLSurfaceView(this);
		// HIDD_BIGB02 should create stencil buffer
		glSurfaceView.setEGLConfigChooser(5, 6, 5, 0, 16, 8);

		return glSurfaceView;
	}

	static {
		System.loadLibrary("cocos2dcpp");
	}
}
