这里只有Android端的JNI方法及实现，IOS的实现不在这里。请移步Android Common下的IOS目录查找

1. 将 jni/utils 目录下的 STSystemFunction.h 放到 cocos2d-x 工程的 Classes 目录下，IOS 和 Android 共用这个头文件。 
2. 将 jni/utils 目录下的其余文件复制到自己Android工程的jni目录下。

3. AnalyticX 为 开源的 fluryy 实现，参见 https://github.com/diwu/AnalyticX
   将 AnalyticX.h 放到 cocos2d-x 工程的 Classes 目录下，IOS 和 Android 共用这个头文件。
   
4. iap 目录下，将 STInAppBilling.h 和 STIABDelegate.h 放到 cocos2d-x 工程的 Classes 目录下，IOS 和 Android 共用这两个头文件。

   注意：在ST_IAB_Android.cpp中 有需要弹窗提示的方法，具体Dialog的内容需要自己定义，考虑到多语言的问题不变统一处理。(已经给出了例子，详见代码的注释)


5. ST_JNI_Helper.h 和 ST_JNI_Helper.cpp 为通用类，在自己工程中只需要一个即可。

6. 另附一个 Android.mk 文件，这个文件无需手动添加编译文件，可直接遍历 Classes 和 jni 目录下所有的 .cpp 和 .c 后缀文件自动添加进行编译。十分方便省力！
   但需要注意，自行更改文件中的 COCOS2DX_ROOT 变量为自己的 cocos2d-x 根目录。

7, DemoActivity.java 为各自工程的 Activity 的一个示例，需要初始化的东西和其他一些东西，仅作为例子。