/** Automatically generated file. DO NOT MODIFY */
package com.common.android;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}